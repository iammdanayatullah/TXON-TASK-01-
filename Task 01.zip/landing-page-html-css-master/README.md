# An elegant landing page using html-css

This project is more than a landing page, because i'm using stylus for compiling css and it's amazing the way to organize de code using variables, imports and other details.

This landing page is 100% responsive. You can use it  to learn and make a lot of cool things.

Clone, enjoy and give me a star!

## Demo
You can see the demo [here](https://anabelisam.github.io/landing-html-css/)

## Preview
![](/preview.png)

After clone this project you have to run:
### Install project
```bash
npm i
```

### Live reload
```bash
npm run start
```

### Compile CSS
```bash
npm run stylus
```
